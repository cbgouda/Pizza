﻿using PizzaOrder.Api.Models;

namespace PizzaOrder.Interfaces.Helpers
{
    public interface ICartSessionService
    {
        Cart GetCart();

        void SetCart(Cart cart);
    }
}
