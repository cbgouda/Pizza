﻿namespace PizzaOrder.Interfaces.Services
{
    public interface IPizzaPriceCalculater
    {
        decimal Calculate(decimal size, decimal pizzaType, int edgeTypeId, int number);
    }
}
