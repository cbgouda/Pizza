﻿using PizzaOrder.Api.Models;
using System.Collections.Generic;

namespace PizzaOrder.Interfaces.Services
{
    public interface ICartService
    {
        void AddTocart(Cart cart, PizzaToAddCart pizza);

        void RemoveFromCart(Cart cart,int pizzaId);

        List<CartLine> GetCartLines(Cart cart);
    }
}
