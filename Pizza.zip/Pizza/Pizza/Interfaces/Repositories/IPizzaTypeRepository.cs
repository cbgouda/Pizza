﻿using PizzaOrder.Api.Models;
using System.Collections.Generic;

namespace PizzaOrder.Interfaces.Repository
{
    public interface IPizzaTypeRepository
    {
        List<PizzaType> GetAllPizzas();

        decimal GetPizzaTypePrice(int pizzaTypeId);

        string GetPizzaTypeName(int pizzaTypeId);
    }
}
