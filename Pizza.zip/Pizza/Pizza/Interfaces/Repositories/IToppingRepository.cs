﻿using System.Collections.Generic;

namespace PizzaOrder.Interfaces.Repository
{
    public interface IToppingRepository
    {
        List<string> GetAllToppings();
    }
}
