﻿using PizzaOrder.Api.Models;
using System.Collections.Generic;

namespace PizzaOrder.Interfaces.Repository
{
    public interface ISizeRepository
    {
        List<Size> GetAllPizzaSizes();

        decimal GetSizeMultiplier(int sizeId);
    }
}
