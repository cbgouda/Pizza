﻿using PizzaOrder.Interfaces.Services;

namespace PizzaOrder.Api.Services.Concrete
{
    public class PizzaPriceCalculater : IPizzaPriceCalculater
    {
        public decimal Calculate(decimal size, decimal pizzaType, int edgeTypeId, int number)
        {
            decimal excessCost = 0;
            if (edgeTypeId==1)
            {
                excessCost = 2;
            }

            decimal price = (pizzaType * size + excessCost)*number;

            return price;
        }
    }
}
