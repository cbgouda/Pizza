﻿namespace PizzaOrder.Api.Models
{
    public class CartToGetDto
    {
        public int MyProperty { get; set; }
    }
}
