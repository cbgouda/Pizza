﻿namespace PizzaOrder.Api.Models
{
    public class CartLine
    {
        public PizzaToAddCart Pizza { get; set; }

        public int Quantity{ get; set; }
    }
}
